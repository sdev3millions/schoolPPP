from django.shortcuts import render
from .models import Schools,SchoolData
from .forms import SchoolForm
# Create your views here.

def home(request):
    return render(request,'index.html')
def school_list(request):
    schooldata = SchoolData.objects.all()
    return render(request,'school/schooldata_list.html', {'schooldata':schooldata})
def school_create(request):
    form=SchoolForm()
    context={'form':form}
    html_form = render_to_string('includes/school_create.html',context,request=request,)
    return JsonResponse({'html_form':html_form})
