from django import forms
from .models import SchoolData

class SchoolForm(forms.ModelForm):
    class Meta:
        model = SchoolData
        fields=('school_id', 'ele_k', 'ele_u','hea_k','hea_u','wat_l', 'wat_u')